import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-article-class',
  templateUrl: './view-article-class.component.html',
  styleUrls: ['./view-article-class.component.css']
})
export class ViewArticleClassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
