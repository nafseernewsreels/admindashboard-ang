import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-headline-class',
  templateUrl: './view-headline-class.component.html',
  styleUrls: ['./view-headline-class.component.css']
})
export class ViewHeadlineClassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
